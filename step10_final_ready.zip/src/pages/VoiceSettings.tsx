import VoiceSettings from '@/components/VoiceSettings';
export default VoiceSettings;
