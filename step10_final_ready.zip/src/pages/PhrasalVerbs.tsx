import PhrasalVerbsMultiSelect from '@/components/PhrasalVerbsMultiSelect';
export default function PhrasalVerbsPage() {
  return <div className="p-4"><PhrasalVerbsMultiSelect /></div>;
}
