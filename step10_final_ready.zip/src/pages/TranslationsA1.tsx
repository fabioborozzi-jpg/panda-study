import React from 'react';
import TranslationExerciseA1 from '../components/TranslationExercise';
export default function TranslationsA1(){
  return <div><TranslationExerciseA1 /></div>
}
