import TranslationExerciseA1 from '@/components/TranslationExercise';
export default function TranslationsA2(){ return <div className='p-4'><TranslationExerciseA1 /></div> }
