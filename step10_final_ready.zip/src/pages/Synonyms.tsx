import SynonymsExercise from '@/components/SynonymsExercise';
export default SynonymsExercise;
