import React from 'react';
import ConjugationExercise from '../components/ConjugationExercise';
export default function Conjugations(){ return <div><ConjugationExercise/></div> }
