import React from 'react';
import TranslationExercise from '../components/TranslationExercise';
export default function Translations(){
  return <div><TranslationExercise /></div>
}
