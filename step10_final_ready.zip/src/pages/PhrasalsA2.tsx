import PhrasalVerbsMultiSelect from '@/components/PhrasalVerbsMultiSelect';
export default function PhrasalsA2(){ return <div className='p-4'><PhrasalVerbsMultiSelect /></div> }
