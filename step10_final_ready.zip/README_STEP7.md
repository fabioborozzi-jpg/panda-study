# Step 7 — TTS (Web Speech API) integrato
- Hook `useVoice` con fallback automatico; default `en-GB` (config via `VITE_VOICE_ACCENT`).
- Phrasal Verbs Multi-Select: 🔊 per significato e per ogni opzione; auto-repeat dei corretti se risposta incompleta/sbagliata.
- Non richiede chiavi API; funziona in browser con Web Speech API.
